<?php
/**
 * 购物车逻辑实现接口
 * @author wsyone wsyone@foxmail.com
 * @date 2018年5月7日下午5:32:53
 * Copyright:钦州市友加信息科技有限公司 All Rights Reserved
 * site: https://www.jihexian.com
 */
namespace api\modules\v1\controllers;
use api\common\controllers\Controller;
use common\models\Cart;
use common\models\Skus;
use common\models\Product;
use common\logic\CartLogic;
use common\logic\SkusLogic;
use common\models\Address;
use common\models\Order;
use yii\filters\auth\QueryParamAuth;
use yii\helpers\ArrayHelper;
use common\helpers\Tools;
use yii;


class CartController extends Controller
{


    public $userId;
    public $user;

    public function behaviors()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            [
                'class' => QueryParamAuth::className(),
                'tokenParam' => 'token',
                'optional' => [
                    'test',
                ]
            ]
        ]);
    }


    /**
     * 购物车列表
     * @sku_id
     * @return [type] [description]
     */
    public function actionIndex()
    {
        //列出购物车数据

        $cart=new CartLogic();
        $uid=Yii::$app->user->id;
        $data=$cart->findCartByUser($uid);
        return $data;
    }
    /**
     * 购物车添加
     *
     */
    public function actionAdd(){

        $data['stock_num'] = Yii::$app->request->post('num');//商品数量
        $data['sku_id']=Yii::$app->request->post('sku_id');
        $data['prom_type']=Yii::$app->request->post('prom_type');//营销活动类型
        $data['prom_id']=Yii::$app->request->post('prom_id');//商品参加的活动
        if ( $cart = Cart::find()->where(['and', 'sku_id="'.$data['sku_id'].'"', 'user_id='.Yii::$app->user->id])->one()) {
            //判断如果有活动推广，更新价格
            $data['total']=$cart['num'] + $data['stock_num'];
        }
        $sku=new SkusLogic($data['sku_id']);
        //判断商品是否下架，活动是否有效
        $vi=$sku->validateSku($data);

        if($vi['status']==1){
            $cart=new CartLogic();
            return $cart->addCart($data);

        }else{
            return $vi;
        }
    }

    public function actionCheckout(){
        if (Yii::$app->request->isPost) {

            $data=Yii::$app->request->post('products');
            $aid=$data['addressInfo']['id'];
            $addr = Address::findOne($aid);
            $order['m_id']=Yii::$app->user->id;
            //获取用户邮寄地址及电话信息
            $order['full_name']= $addr['userName'];
            $order['prov']=$addr['provinceName'];
            $order['city']=$addr['cityName'];
            $order['area']=$addr['countyName'];
            $order['address']=$addr['detailInfo'];
            $order['tel']=$addr['telNumber'];
            //获取订单相关价格
            if(!empty($data['productIdArr'])){ //购物车
                $order['sku_price']=0;//商品市场价格
                $order['sku_price_real']=$data['total'];//产品实际价格
            }else{                            //直接购买

            }
            $order['discount_price']=0;//改价
            $order['coupons_id']=0;//优惠券id
            $order['coupons_price']=0;//优惠券金额

            //获取邮费价格
            $order['delivery_price']=$data['freight'];//实际的邮费价格
            $order['delivery_price_real']=$data['freight'];//实际的邮费价格
            $order['order_price']=$data['total']+$data['freight'];
            $order['m_desc']=$data['message'];
            $order['delivery_id']=1;//默认快递
            $order['is_shop_checkout']=1;//默认已经结算
            $order['payment_id']=1;//支付方式，默认为微信支付
            return $order;
           // $model = new Order();


        }
    }
    //修改购物车商品数量
    public function actionChange(){
        $num=Yii::$app->request->post('num');
        $id=Yii::$app->request->post('id');
        if($num > 200){
            $num = 200;
        }
        if($num&&$id){
            //获取购物车某个购物车里商品数据
            Cart::updateAll(['num' => $num], ['user_id' => Yii::$app->user->id, 'id' => $id]);
            return ['status' => 1, 'msg' => '修改商品数量成功', 'result' => ''];
        }
    }
    //删除购物车数据
    public function actionDelete(){
        $id=Yii::$app->request->post('id');
        if(Cart::deleteAll(['user_id' => Yii::$app->user->id, 'id' => $id])){
            return ['status' => 1, 'msg' => '删除成功', 'result' => ''];
        }else{
            return ['status' => 0, 'msg' => '删除失败', 'result' => ''];
        }
    }

    /**
     * [计算购物车已经选择的商品总价，并返回全部购物车商品信息]
     * @return array $cart
     *
     */
    public function actionCalculator(){
         
        $cartList=$cartSelectedId = $cartNoSelectedId = [];
        if (empty($cart)) {
            return ['status' => 0, 'msg' => '购物车没商品'];
        }
        foreach ($cart as $key => $val) {

            if ($cart[$key]['selected'] == 1) {
                $cartSelectedId[] = $cart[$key]['id'];
            } else {
                $cartNoSelectedId[] = $cart[$key]['id'];
            }
        }


        if (!empty($cartNoSelectedId)) {
            Cart::updateAll(['selected' =>0], ['and','user_id' => Yii::$app->user->id, ['in','id',$cartNoSelectedId]]);

        }
        $cartList = Cart::find()->joinWith('skus')->where(['and','user_id' =>Yii::$app->user->id, ['in','id',$cartSelectedId]])->asArray()->all();
        //选择的数据更改数据库数据同步
        foreach($cartList as $cartKey=>$cartVal){
            if($cartList[$cartKey]['selected'] ==0||$cartList[$cartKey]['selected']){

                Cart::updateAll(['selected' =>1], ['and','user_id' => Yii::$app->user->id, ['in','id',$cartSelectedId]]);
                break;
            }
        }
        $all = Cart::find()->joinWith('skus')->where(['user_id' => Yii::$app->user->id])->asArray()->all();

        foreach ($all as $key => $value) {
            $product_image=Tools::get_product_image($all[$key]['skus']['product_id']);
            //计算被选中的总价
            $all[$key]['skus']['image']=$value['skus']['image']!=''?Yii::$app->params['domain'].$value['skus']['image']: Yii::$app->params['domain'].$product_image;
            $all[$key]['skus']['thumbImg']=$value['skus']['thumbImg']!=''?Yii::$app->params['domain'].$value['skus']['thumbImg']:Yii::$app->params['domain'].$product_image;
        }
        if ($cartList) {
            $cart=new CartLogic();
            //获取订单总价、总的商品重量
            $data=$cart->get_total($cartList);
            return ['status' =>1, 'select'=> $cartSelectedId,'msg' => '计算成功', 'items'=>$all,'total'=>$data['total'],'market_total'=>$data['market_total'],'weight'=>$data['weight']];

        } else {
            return ['status' => 1, 'msg' => '购物车没选中商品', 'total'=>0,'items' =>$all];
        }

    }
    /**
     * [actionEestory 清空购物车]
     * @return [type] [description]
     */
    public function actionEestory(){
        if(Cart::deleteAll(['user_id' => Yii::$app->user->id])){
            return ['status' => 1, 'msg' => '删除成功', 'result' => ''];
        }else{
            return ['status' => 0, 'msg' => '删除失败', 'result' => ''];
        }

    }
    /**
     * [获取已经被选择的商品]
     * @return [type] [description]
     */
    public function actionGetdata(){
        $cart=new CartLogic();
        $uid=Yii::$app->user->id;
        $cartList=$cart->findCartBySelect($uid);
        return $cartList;
    }

    //获取直接购买商品的详细信息
    public function actionGetbuy(){
        $condition['sku_id']=$sku_id=Yii::$app->request->post('sku_id');
        $condition['stock_num']=$num=Yii::$app->request->post('num');
        $condition['prom_type']=Yii::$app->request->post('prom_type');
        $condition['prom_id']=Yii::$app->request->post('prom_id');
        $sku=new SkusLogic($sku_id);
        //判断商品是否下架，活动是否有效
        $vi=$sku->validateSku($condition);
        if($vi['status']==1) {
            $data = Skus::find()->where(['sku_id' => $sku_id])->one();
            $product_image = Tools::get_product_image($data['product_id']);
            $data['image'] = $data['image'] != '' ? Yii::$app->params['domain'] . $data['image'] : Yii::$app->params['domain'] . $product_image;
            $data['thumbImg'] = $data['thumbImg'] != '' ? Yii::$app->params['domain'] . $data['thumbImg'] : Yii::$app->params['domain'] . $product_image;
            $str = Tools::get_skus_value($data['sku_values']);
            $goods = Product::find()->where(['product_id' => $data['product_id']])->one();
            if($condition['prom_type']!=0&$condition['prom_id']!=0){
                $price=$data['prom']['price'];
            }else{
                $price= Tools::get_member_price($data['sale_price']);
            }

            $info[0] = ['skus' => $data, 'product_name' => $goods['name'], 'product_id' => $data['product_id'], 'num' => $num, 'sku_values' => $str, 'member_goods_price' =>$price];
            $total = $price * $num;
            $market_total = $data['market_price'] * $num;
            return ['items' =>$info, 'total' => $total, 'market_total' => $market_total, 'str' => $str,'status'=>1];
        }else{
            return $vi;
        }
    }

    /**
     *测试
     */

    public function actionTest(){
        $sku_id=Yii::$app->request->post('sku_id');
        $data=Skus::findOne($sku_id);
        return $data;
        /*     $product=Product::findOne(108);

             return  ['image'=>$product['image'][0]['thumbImg']];*/


    }



}