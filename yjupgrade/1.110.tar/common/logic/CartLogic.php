<?php
/**
 * Created by PhpStorm.
 * Author: wsyone  wsyone@foxmail.com
 * Time: 2018-05-31 16:49
 * Copyright:钦州市友加信息科技有限公司 All Rights Reserved
 * site: http://www.jihexian.com
 */
namespace common\logic;
use common\components\Controller;
use common\models\Cart;
use common\models\Product;
use common\models\Skus;
use common\helpers\Tools;
use common\models\OrderSku;

use common\modules\promotion\models\FlashSale;
use yii;
class CartLogic{
    public $obj;
    public function __construct()
    {
        $this->obj=new Cart();

    }
    /**
     * 添加购物车
     * @param $sku_id
     * @param $num
     * @param int $prom_type
     * @param int $prom_id
     */
  public function addCart($data){
      //购物车有数据，添加数量
       if ( $cart = Cart::find()->where(['and', 'sku_id="'.$data['sku_id'].'"', 'user_id='.Yii::$app->user->id])->one()) {
           //判断如果有活动推广，更新价格
            if($cart->updateAllCounters(['num' =>$data['stock_num']], ['and', 'sku_id="'.$data['sku_id'].'"', 'user_id='.Yii::$app->user->id])){
                return ['status' => 1, 'msg' => '添加成功'];
            }else{
                return ['status' => 0, 'msg' => '添加失败'];
            }
        } else { //购物车里面没有数据时，执行添加
           $model = Skus::findOne($data['sku_id']);
            $product = $model->product;
                $cart = new Cart();
                $cart->session_id = Yii::$app->session->id;
                $cart->user_id = Yii::$app->user->id;
                $cart->product_id = $model->product_id;
                $cart->market_price = $model->market_price;
                //如果是活动商品
                if (!empty($model->prom)) {
                    $cart->sale_price = $model->prom->price;
                    $cart->member_goods_price = Tools::get_member_price($model->prom->price);
                } else {
                    $cart->sale_price = $model->sale_price;
                    $cart->member_goods_price = Tools::get_member_price($model->sale_price);
                }
                $cart->sku_id = $data['sku_id'];
                $cart->num = $data['stock_num'];
                $cart->prom_type=$data['prom_type'];
                $cart->prom_id=$data['prom_id'];
                $cart->product_name = $product['name'];
                $cart->product_sn = $product['product_sn'];
                $str = Tools::get_skus_value($model['sku_values']);
                //插入属性值
                $cart->sku_values = $str;
                if ($cart->save()) {
                    return ['status' => 1, 'msg' => '添加成功'];
                } else {
                    return ['status' => 0, 'msg'=>'添加失败'];
                }
           }
        }

    /**
     * 判断添加的sku_id是否已经存在购物车列表中
     * @param $sku_id
     * @return array
     */
    public function isInCart($sku_id)
    {
       $cart = Cart::find()->where(['and', 'sku_id="' .$sku_id . '"', 'user_id=' . Yii::$app->user->id])->one();
       if($cart){
          return $cart;//购物车里有记录
       }else{
         return false;//购物车里没有记录
       }

    }
    /**
     * 正常添加购物车
     * array $data
     * @return array
     */
    public function addNormalCart($data){

        //判断购物车是否已经存在数据，已有数据时，执行更新操作


    }


    /**
     * @return array
     * total 商品总价
     * market_total 市场总价
     * weight 总重量
     */

    public function get_total($cartList){

        $data=array();
        $data['total']=0;
        $data['market_total']=0;
        $data['weight']=0;
        foreach ($cartList  as $key=>$value){
            $data['total']+=$value['member_goods_price']*$value['num'];//商城总价
            $data['market_total']+=$value['market_price']*$value['num'];//市场总价
            $data['weight']+=$value['skus']['weight']*$value['num'];//总重量
        }
        return $data;

    }


    /**
     * 获取用户购物车信息
     * @return ['items'=>$cart,'total'=>$total,'market_total'=>$market_total]
     */
    public function findCartByUser($uid){

        $cart = Cart::find()->where(['user_id'=>$uid])->joinWith('skus')->all();
              $market_total=0;
              $total=0;

              //输出已选择的数据
              foreach ($cart as $key => $value) {
              //商品封面

                  $product= $value->product;
                  $product_image=$product[0]['image'][0]['thumbImg'];
                // $skus=$value->skus;

                 ///计算被选中的总价
                  $cart[$key]['skus']['image']=$value['skus']['image']!=''?Yii::$app->params['domain'].$value['skus']['image']:Yii::$app->params['domain'].$product_image;
                  $cart[$key]['skus']['thumbImg']=$value['skus']['thumbImg']!=''?Yii::$app->params['domain'].$value['skus']['thumbImg']:Yii::$app->params['domain'].$product_image;
                  if($value['selected']==1){
                      $total+=$value['member_goods_price']*$value['num'];//商城总价
                      $market_total+=$value['market_price']*$value['num'];//市场总价
                  }

                  # code...
              }

              return ['items'=>$cart,'total'=>$total,'market_total'=>$market_total];
          }


          /**
           * 获取用户购物车被选择的购物信息
           * @return ['items'=>$cart,'total'=>$total,'market_total'=>$market_total]
           */
    public function findCartBySelect($uid){
        //$cart = Cart::find()->joinWith('skus')->where(['or', 'session_id = "' . Yii::$app->session->id . '"', 'user_id = ' . (Yii::$app->user->id ? Yii::$app->user->id :0)])->asArray()->all();
        $cart = Cart::find()->joinWith('skus')->where(['and','selected=1','user_id='.$uid])->asArray()->all();
        $total=0;
        $market_total=0;
        //输出已选择的数据
        foreach ($cart as $key => $value) {
            /*商品封面*/
            $product_image=Tools::get_product_image($cart[$key]['skus']['product_id']);
            //计算被选中的总价
            $cart[$key]['skus']['image']=$value['skus']['image']!=''?Yii::$app->params['domain'].$value['skus']['image']:Yii::$app->params['domain'].$product_image;
            $cart[$key]['skus']['thumbImg']=$value['skus']['thumbImg']!=''?Yii::$app->params['domain'].$value['skus']['thumbImg']:Yii::$app->params['domain'].$product_image;

            $total+=$value['member_goods_price']*$value['num'];//商城总价
            $market_total+=$value['market_price']*$value['num'];//市场总价

            # code...
        }
        return ['items'=>$cart,'total'=>$total,'market_total'=>$market_total];
    }

    /**
     * @return array
     * 购物车提交过来的数据，下单时进行order_sku数据插入及删除购物车数据
     * @throws yii\db\Exception
     */
    public function dealCart($order_id,$order_no,$CartArr){
        $ids=[];
        $pp=array();
        foreach($CartArr as $key=>$va){
            $ids[]=$va['product_id'].',';
        }
        $skus=Cart::find()->where(['and','user_id' =>Yii::$app->user->id, ['in','id',$ids]])->joinWith('skus')->asArray()->all();
        if(!empty($skus)){
            foreach ($skus as $key=>$va) {
                $order_sku[$key]['order_id']=$order_id;
                $order_sku[$key]['order_no']=$order_no;
                $order_sku[$key]['goods_id']=$va['product_id'];
                $order_sku[$key]['goods_name']=$va['product_name'];
                $order_sku[$key]['sku_id']=$va['sku_id'];
                $order_sku[$key]['sku_no']=$va['skus']['sku_num'];//sku商品条形码
                $order_sku[$key]['sku_image']=$va['skus']['image'];
                $order_sku[$key]['sku_thumbImg']=$va['skus']['thumbImg'];
                $order_sku[$key]['num']=$va['num'];//数量
                $order_sku[$key]['sku_market_price']=$va['skus']['market_price'];
                $order_sku[$key]['sku_sell_price_real']=$va['skus']['sale_price'];
                $order_sku[$key]['sku_value']=$va['sku_values'];
            }
            $connection = \Yii::$app->db;
            //数据批量入库
            $tt= $connection->createCommand()->batchInsert(
                'yj_order_sku',
                ['order_id','order_no','goods_id','goods_name','sku_id','sku_no','sku_image','sku_thumbImg','num','sku_market_price','sku_sell_price_real','sku_value'],//字段
                $order_sku
            )->execute();
            if(!empty($tt)){
                Cart::deleteAll(['and','user_id' =>Yii::$app->user->id, ['in','id',$ids]]);
                return 1;
            }}else{
               return -1;
        }
    }

    /**
     * 直接购物处理的逻辑
     */
    public function dealBuy($order_id,$order_no,$sku_id,$num){
        $skus=Skus::find()->joinWith('product')->where(['sku_id'=>$sku_id])->asArray()->one();

       $orderSku = new OrderSku();

                $orderSku->order_id=$order_id;
                $orderSku->order_no=$order_no;
                $orderSku->goods_id=$skus['product_id'];
                $orderSku->goods_name=$skus['product']['name'];
                $orderSku->sku_id=$skus['sku_id'];
                $orderSku->sku_no=$skus['sku_num'];//sku商品条形码
                $orderSku->sku_image=$skus['image'];
                $orderSku->sku_thumbImg=$skus['thumbImg'];
                $orderSku->num=$num;//数量
                $orderSku->sku_market_price=$skus['market_price'];
                $orderSku->sku_sell_price_real=$skus['sale_price'];
                $orderSku->sku_value=Tools::get_skus_value($skus['sku_values']);
                $transaction = Yii::$app->db->beginTransaction();
                try{
                    $orderSku->save();
                    $transaction->commit();
                    return 1;
                } catch (\Exception $e) {
                    $transaction->rollBack();
                    //Yii::$app->session->setFlash('error', $e->getMessage());
                    return -1;
                }

    }


}