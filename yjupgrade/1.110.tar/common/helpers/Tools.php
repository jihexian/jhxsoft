<?php
/*
 * Created by PhpStorm.
 * Author: wsyone  wsyone@foxmail.com
 * Time: 2018-07-03 10:24
 * Copyright:钦州市友加信息科技有限公司 All Rights Reserved
 * site: http://www.jihexian.com
 */
namespace  common\helpers;
use common\models\Order;
use common\models\Product;
use common\models\Skus;
use common\models\OrderSku;
use common\models\Member;
use yii;
use yii\helpers\ArrayHelper;
class Tools{

    /**
     * 转换skus_value的格式，从json改为sting
     */
    public static function get_skus_value($value){
        $su=json_decode($value,true);
        $str='';
        foreach ($su as $key => $value) {
            $str.=$key.':'.$value[0].' ';
            # code...
        }
        return $str;
    }

    //生成订单序列号
    public static function get_order_no(){
        return date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }

   //获取会员价格
   public static function get_member_price($price){
        return $price;

    }

    /**

     * 支付完成修改订单

     * @param $order_no 订单号

     * @param array $ext 额外参数

     * @return bool|void

     */
    public static function update_pay_status($order_no,$ext=array()){
        if(stripos($order_no,'recharge') !== false){

            //用户在线充值逻辑

        }else{
            $order=Order::find()->where(['order_no'=>$order_no])->one();
            if($order['payment_status']==0){
                $transaction = Yii::$app->db->beginTransaction();
                try {
                    $order->payment_status=1;
                    $order->status=2;
                    $order->paytime=time();
                    $order->payment_no=$ext['transaction_id'];
                    $order->payment_id=1;//支付方式为微信支付
                    $order->save();
                    if($order->hasErrors()) {
                        return ['status'=>-2,'msg'=> $order->errors];
                    }

                    $orderSku= $order->orderSku;
                    foreach ($orderSku as $key=>$value){
                        //修改库存
                        $post = Skus::findOne($value['sku_id']);
                        $post->updateCounters(['stock' => -$value['num']]);
                        //修改销量
                        $product=Product::findOne($value['goods_id']);
                        $product->updateCounters(['sale'=>$value['num']]);

                    }

                    $transaction->commit();
                    return ['status'=>1,'msg'=>'操作成功'];

                } catch(\Exception $e) {
                    $transaction->rollBack();
                    yii::warning($e->getMessage());
                    return ['status'=>0,'msg'=>$e->getMessage()];
                }
            }

        }


        }

        /**
         * 用户id获取用户名称
         * @param $m_id 用户id
         * @return mixed
         */
        public static function get_user_name($m_id){
           $data=Member::findOne($m_id);
           return $data['username'];

        }
    //获取支付状态
    /*将数字状态转成文字*/
    public static function get_status($status){
        $str="";
        switch ($status)
        {

            case 1:
                $str="待支付";
                break;
            case 2:
                $str="待发货";
                break;
            case 3:
                $str="已发货";
                break;
            case 4:
                $str="待评价";
                break;
            case 5:
                $str="已评价";
                break;
            case 6:
                $str="已退款";
                break;
            case 7:
                $str="部分退款";
                break;
            case 8:
                $str="用户取消";
                break;
            case 9:
                $str="超时作废";
                break;
            case 10:
                $str="退款中";
                break;
            default:
                $str="未知状态";
        }
        return $str;
    }

    public static function pay_status($status)
    {
        $str = "";
        switch ($status) {
            case 0:
                $str = "未支付";
                break;
            case 1:
                $str = "已支付";
                break;
            default:
                $str="未支付";
        }
        return $str;
    }

    /**
     * 获取商品图片封面
     * @param $product_id
     * @return mixed
     */
    public static function get_product_image($product_id){
        $product=Product::findOne($product_id);
        return $product['image'][0]['thumbImg'];


    }




}