<?php

namespace common\models;
use yii\behaviors\AttributeBehavior;
use yii\behaviors\TimestampBehavior;
use Yii;

/**
 * This is the model class for table "{{%order}}".
 *
 * @property string $id
 * @property integer $m_id
 * @property string $order_no
 * @property integer $payment_id
 * @property string $payment_name
 * @property integer $payment_status
 * @property string $payment_no
 * @property integer $delivery_id
 * @property string $delivery_name
 * @property string $delivery_time
 * @property integer $delivery_status
 * @property integer $shop_id
 * @property integer $is_shop_checkout
 * @property integer $status
 * @property string $full_name
 * @property string $tel
 * @property string $prov
 * @property string $city
 * @property string $area
 * @property string $address
 * @property string $sku_price
 * @property string $sku_price_real
 * @property string $delivery_price
 * @property string $delivery_price_real
 * @property string $discount_price
 * @property string $order_price
 * @property string $pay_amount
 * @property integer $coupons_id
 * @property string $coupons_price
 * @property integer $order_prom_id
 * @property string $order_prom_money
 * @property integer $integral
 * @property string $integral_money
 * @property string $user_money
 * @property string $m_desc
 * @property string $admin_desc
 * @property integer $create_time
 * @property integer $paytime
 * @property integer $sendtime
 * @property integer $completetime
 * @property integer $is_del
 * @property string $invoice_title
 * @property string $taxpayer
 * @property integer $is_distribut
 * @property string $paid_money
 * @property integer $update_time
 * @property string $parent_sn
 * @property integer $prom_type
 * @property integer $prom_id
 */
class Order extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%order}}';
    }

    public function behaviors(){
        return [
            [
                'class' => AttributeBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => 'order_no',
                ],
                'value' => function ($event) {
                    return date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
                },
            ],
            [
                'class'=>TimestampBehavior::className(),
                'attributes'=>[
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_time','updated_time'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['update_time'],
                ]
            ]
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['m_id', 'payment_id', 'payment_name', 'delivery_id', 'is_shop_checkout', 'sku_price', 'sku_price_real', 'delivery_price', 'delivery_price_real', 'discount_price', 'order_price', 'pay_amount', 'coupons_id', 'coupons_price'], 'required'],
            [['m_id', 'payment_id', 'delivery_id', 'shop_id', 'is_shop_checkout', 'coupons_id', 'order_prom_id', 'integral', 'create_time', 'paytime', 'sendtime', 'completetime', 'update_time', 'prom_type', 'prom_id'], 'integer'],
            [['sku_price', 'sku_price_real', 'delivery_price', 'delivery_price_real', 'discount_price', 'order_price', 'pay_amount', 'coupons_price', 'order_prom_money', 'integral_money', 'user_money', 'paid_money'], 'number'],
            [['order_no'], 'string', 'max' => 32],
            [['payment_name', 'delivery_name', 'taxpayer'], 'string', 'max' => 45],
            [['payment_status', 'delivery_status', 'is_del', 'is_distribut'], 'string', 'max' => 1],
            [['payment_no', 'delivery_time', 'full_name', 'tel'], 'string', 'max' => 50],
            [['status'], 'string', 'max' => 2],
            [['prov', 'city', 'area'], 'string', 'max' => 100],
            [['address'], 'string', 'max' => 200],
            [['m_desc', 'admin_desc'], 'string', 'max' => 255],
            [['invoice_title'], 'string', 'max' => 145],
            [['parent_sn'], 'string', 'max' => 80],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'm_id' => Yii::t('app', '用户id'),
            'order_no' => Yii::t('app', '订单号'),
            'payment_id' => Yii::t('app', '支付方式0为货到付款'),
            'payment_name' => Yii::t('app', '支付方式名称'),
            'payment_status' => Yii::t('app', '支付状态'),//0未支付1已经支付'
            'payment_no' => Yii::t('app', '第三方支付交易号'),
            'delivery_id' => Yii::t('app', '配送方式'),
            'delivery_name' => Yii::t('app', '快递名称'),
            'delivery_time' => Yii::t('app', '配送时间'),
            'delivery_status' => Yii::t('app', '发货状态'),//0未发货1已发货2为部分发货'
            'shop_id' => Yii::t('app', '店铺id'),
            'is_shop_checkout' => Yii::t('app', '是否给店铺结算货款 0:未结算;2:等待结算1:已结算'),
            'status' => Yii::t('app', '订单状态 '),//1生成订单,2支付订单,3已经发货,4完成订单,5已经评价6退款,7部分退款8用户取消订单,9作废订单,10退款中
            'full_name' => Yii::t('app', '收货人姓名'),
            'tel' => Yii::t('app', '收货人电话'),
            'prov' => Yii::t('app', '省'),
            'city' => Yii::t('app', '市'),
            'area' => Yii::t('app', '区'),
            'address' => Yii::t('app', '详细地址'),
            'sku_price' => Yii::t('app', '商品市场总价单位'),
            'sku_price_real' => Yii::t('app', '商品销售价格单位'),
            'delivery_price' => Yii::t('app', '物流原价单位'),
            'delivery_price_real' => Yii::t('app', '物流支付价格单位'),
            'discount_price' => Yii::t('app', '改价金额单位'),
            'order_price' => Yii::t('app', '订单总金额单位'),
            'pay_amount' => Yii::t('app', '应付总价'),//订单总价order_price+邮费价格deliver_price+改价金额+活动减价+积分抵扣-用户使用余额
            'coupons_id' => Yii::t('app', '优惠券id'),
            'coupons_price' => Yii::t('app', '优惠券金额'),
            'order_prom_id' => Yii::t('app', '订单活动（如满减活动）'),
            'order_prom_money' => Yii::t('app', '订单活动扣除金额'),
            'integral' => Yii::t('app', '使用积分'),
            'integral_money' => Yii::t('app', '积分抵扣金额'),
            'user_money' => Yii::t('app', '用户使用余额'),
            'm_desc' => Yii::t('app', '用户备注'),
            'admin_desc' => Yii::t('app', '管理员备注'),
            'create_time' => Yii::t('app', '下单时间'),
            'paytime' => Yii::t('app', '支付时间'),
            'sendtime' => Yii::t('app', '发货时间'),
            'completetime' => Yii::t('app', '完成时间'),
            'is_del' => Yii::t('app', '0为正常1为删除'),
            'invoice_title' => Yii::t('app', '发票抬头'),
            'taxpayer' => Yii::t('app', '税务识别号'),
            'is_distribut' => Yii::t('app', '是否已分成'),
            'paid_money' => Yii::t('app', '订金'),
            'update_time' => Yii::t('app', 'Update Time'),
            'parent_sn' => Yii::t('app', '父单单号'),
            'prom_type' => Yii::t('app', 'Prom Type'),
            'prom_id' => Yii::t('app', 'Prom ID'),
        ];
    }

    public function getOrderSku()
    {
        return $this->hasMany(OrderSku::className(), ['order_id' => 'id']);
    }

    /*   public function imagesAddPrefix(){
           $images = $this->sku_image;
           $images = Util::ImagesAddPrefix($images,'sku_image');
           $images = Util::ImagesAddPrefix($images,'sku_thumbImg');
           $this->image = $images;
           $this->content = Util::ImagesAddPrefix($this->content,'img src="');
       }*/

    public function get_user_name($uid){
        $data=Member::findOne($uid);
        return $data['usernmae'];
    }

    /**
     * @return array 订单状态
     */
    public  function getStatusList()
    {
        return [
            0=> '待审',
            1=> '待支付',
            2=> '待发货',
            3=> '已发货',
            4=> '待评价',
            5=> '已评价',
            6=> '已退款',
            7=> '部分退款',
            8=> '用户取消',
            9=> '超时作废',
            10=> '退款中',
        ];
    }
    public  function getPayStatusList()
    {
        return [

            0=> '待支付',
            1=> '已支付',
        ];
    }
}
