<?php
return [

    'domain'=>env('SITE_URL'),  //api图片服务器地址
    'defaultImg' => array(
        'default' => env('SITE_URL').'/web/storage/upload/default.jpg',
    ),
    'xcx_appid' =>env('XCX_APPID'),  //小程序appid
    'xcx_appsecret' =>env('XCX_APPSECRET'),  //小程序appsecret
    'mchid'=>env('MCHID'),
    'key'=>env('KEY'),
    'user.passwordResetTokenExpire' => 3600,
    'webuploader_driver' => env('WEBUPLOADER_DRIVER', 'local'),
    'webuploader_qiniu_config' => [
        'domain' => env('WEBUPLOADER_QINIU_DOMAIN'),
        'bucket' => env('WEBUPLOADER_QINIU_BUCKET'),
        'accessKey' => env('WEBUPLOADER_QINIU_ACCESS'),
        'secretKey' => env('WEBUPLOADER_QINIU_SECRET'),
    ]
];

